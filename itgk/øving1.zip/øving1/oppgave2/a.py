print('Jeg elsker ITGK!')
