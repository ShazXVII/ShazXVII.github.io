print('Norge')
print()
print('Areal (kv.m):', 385180)
print('Folketall (mill.):', 5.3)
