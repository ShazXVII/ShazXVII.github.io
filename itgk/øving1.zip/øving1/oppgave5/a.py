tall1 = float(input("Skriv inn et flyttall"))
tall2 = float(input("Skriv inn et nytt flyttall"))
tall3 = float(input("Skriv inn et siste flyttall"))

print("Konvertert til heltall blir det", int(tall1), int(tall2), int(tall3))

heltall = int(input("Skriv inn et heltall"))
print("Konvertert til flyttall blir det", float(heltall))
