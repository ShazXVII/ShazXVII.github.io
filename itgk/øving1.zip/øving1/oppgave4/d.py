navn = "Per"
ideal_alder = 42
kundensAlder = 37
differanse = (ideal_alder - kundensAlder)
print(navn, "er", differanse, "år unna idealalderen")
