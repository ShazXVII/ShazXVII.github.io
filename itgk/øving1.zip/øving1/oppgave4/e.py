navn = "Erik"
alder = 18
print("Jeg heter ", navn, ", og er ", alder, " år.", sep='')
