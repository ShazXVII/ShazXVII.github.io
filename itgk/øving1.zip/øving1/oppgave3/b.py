print(355, "minutt blir", 355 // 60, "timer og", 355 % 60, "minutt.")
print(403, "sekund blir", 403 // 60, "minutt og", 403 % 60, "sekund.")
print(67, "dager blir", 67 // 7, "uker og", 67 % 7, "dager.")
print(100, "timer blir", 100 // 24, "døgn og", 100 % 24, "timer.")
